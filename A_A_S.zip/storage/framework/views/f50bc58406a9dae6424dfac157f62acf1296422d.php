<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Home</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
					<p style="text-align:center;">
						Welcome to the Aston Animal Sanctuary website. <br>
						<br>
						Here you can view the animals available for adoption here at AAS, and request to adopt animals you like the look of. <br>
						 <br>
						Please use the login button in the top right hand corner to access your account. <br>
						<br>
						If you are a new user, simply register using the register button.
						</p>
					<?php else: ?>
					<p style="text-align:center;">
					<?php if(Auth()->user()->isStaff()): ?>
						Use the 'Animals' tab to view all the animals at AAS and their status. <br>
						<br>
						Use the 'Add Animal' tab to add a new animal to the database. <br>
						<br>
						Use the 'Requests' tab to view the current pending adoption requests.
					</p>
					<?php else: ?>
					<p style="text-align:center;">
						On the 'Animals' page you can see all the animals we currently have available for adoption. <br>
						If you wish to adopt an animal, click the 'Request to Adopt' button alongside the desired animal. <br>
						 <br>
						On the 'Requests' page you can see all the adoption requests you have made, and whether they have been approved or denied. <br>
						<br>
						We hope you find the animal you are after!
					<?php endif; ?>
					<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>