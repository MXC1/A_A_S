<?php $__env->startSection('content'); ?>
<?php if(Auth()->user()->isStaff()): ?>
<div class="listcontainer">
	<div class="row justify-content-center">
		<div class="col-md-8 ">
			<div class="card">
				<div class="card-header">Display all users</div>
				<div class="card-body">
					<table class="table table-striped">
						<thead>
							<tr>
								<th>ID</th>
								<th>Username</th>
								<th>Email</th>
								<th>Role</th>
								<th>User Since</th>
							</tr>
						</thead>
						<tbody>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($user['id']); ?></td>
								<td><?php echo e($user['name']); ?></td>
								<td><?php echo e($user['email']); ?></td>
								<td>
								<?php if($user['role']==0): ?>
								<button class="alert badge-primary" style="width: 100px"> User</button>
								<?php else: ?>
								<button class="alert badge-primary" style="width: 100px"> Admin</button>
								<?php endif; ?>
								</td>
								<td><?php echo e($user['created_at']); ?></td>
								<td>
									<a href="<?php echo e(action('UserController@show', $user['id'])); ?>" class="btn
 btn-primary">Details</a>
								</td>
								<td>
									<form action="<?php echo e(action('UserController@destroy', $user['id'])); ?>"
method="post"> <?php echo csrf_field(); ?>
										<input name="_method" type="hidden" value="DELETE">
											<button class="btn btn-danger" type="submit"> Delete</button>
										</form>
									</td>
								</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php else: ?>
<div class="row justify-content-center">
	<div class="alert alert-danger">
					You are not authorised to view this page
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>