<?php $__env->startSection('content'); ?>

<?php

use App\Animal;

?>

<div class="listcontainer">
	<div class="row justify-content-center">
		<div class="col-md-8 ">
			<div class="card">
				<div class="card-header">Your adoption requests</div>
				<div class="card-body">
<?php if(\Session::has('success')): ?>
				<div class="alert alert-success">
					<p><?php echo e(\Session::get('success')); ?></p>
				</div>
				<br />
<?php endif; ?>
					<table class="table table-striped">
						<thead>
							<tr>
								<th>Request ID</th>
								<th>Animal Name</th>
								<th></th>
								<th>Status</th>
							</tr>
						</thead>
						
						<tbody>
<?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($request['id']); ?></td>
								<td><?php echo e(Animal::find($request['animalid'])->name); ?></td>
								<td>
									<a href="<?php echo e(action('AnimalController@show', $request['animalid'])); ?>" class="btn btn-primary">Animal Details</a>
								</td>
								<td>
								<?php if($request['approved']==0): ?>
								<label class="alert badge-secondary"> Not Yet Approved</label>
								<?php elseif($request['approved']==1): ?>
								<button class="alert badge-success"> Approved</button>
								<?php elseif($request['approved']==2): ?>
								<button class="alert badge-danger"> Denied</button>
								<?php endif; ?>
								</td>
								</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>