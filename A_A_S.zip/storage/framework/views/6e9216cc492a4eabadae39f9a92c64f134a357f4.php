<?php 

use App\User;

?>


<?php $__env->startSection('content'); ?>
<div class="listcontainer">
	<div class="row justify-content-center">
		<div class="col-md-8 ">
			<div class="card">
				<div class="card-header">Display all animals</div>
				<div class="card-body">
<?php if(\Session::has('success')): ?>
				<div class="alert alert-success">
					<p><?php echo e(\Session::get('success')); ?></p>
				</div>
				<br />
<?php endif; ?>
					<table class="table table-striped">
						<thead>
							<tr>
								<th>ID</th>
								<th>Picture</th>
								<th>Name</th>
								<th>Species</th>
								<th>Date of Birth</th>
								<th>Description</th>
								<th>Status</th>
								<th>Owner</th>
							</tr>
						</thead>
						
						<tbody>
<?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($animal['id']); ?></td>
								<td><a target="_blank" href="/storage/images/<?php echo e($animal['image']); ?>"><img width="50px" src="/storage/images/<?php echo e($animal['image']); ?>"></a></td>
								<td><?php echo e($animal['name']); ?></td>
								<td><?php echo e($animal['species']); ?></td>
								<td><?php echo e($animal['dob']); ?></td>
								<td><?php echo e($animal['description']); ?></td>
								<td>
								<?php if($animal['ownerid']==null): ?>
									<label class="alert badge-secondary"> Not Adopted</label>
									</td>
									<td></td>
								<?php else: ?>
									<button class="alert badge-success"> Adopted</button>
									</td>
									<td><?php echo e(User::find($animal['ownerid'])->name); ?></td>
								<?php endif; ?>
								<td>
									<a href="<?php echo e(action('AnimalController@show', $animal['id'])); ?>" class="btn
 btn-primary">Details</a>
								</td>
								<td>
									<a href="<?php echo e(action('AnimalController@edit', $animal['id'])); ?>" class="btn
btn- warning">Edit</a>
								</td>
								<td>
									<form action="<?php echo e(action('AnimalController@destroy', $animal['id'])); ?>"
method="post"> <?php echo csrf_field(); ?>
										<input name="_method" type="hidden" value="DELETE">
											<button class="btn btn-danger" type="submit"> Delete</button>
										</form>
									</td>
								</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>