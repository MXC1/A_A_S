<?php $__env->startSection('content'); ?>
<?php if(Auth()->user()->isStaff()): ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8 ">
			<div class="card">
				<div class="card-header">User Details</div>
				<div class="card-body">
					<table class="table table-striped" border="1" >
						<tr>
							<td>
								<b>ID</th>
								<td><?php echo e($user['id']); ?></td>
							</tr>
							<td>
								<b>Username</th>
								<td><?php echo e($user['name']); ?></td>
							</tr>
							<tr>
								<th>Email</th>
								<td><?php echo e($user['email']); ?></td>
							</tr>
							<tr>
								<th>Role</th>
								<td>
								<?php if($user['role']==0): ?>
								<button class="alert badge-primary" style="width: 100px"> User</button>
								<?php else: ?>
								<button class="alert badge-primary" style="width: 100px"> Admin</button>
								<?php endif; ?>
								</td>
							</tr>
							<tr>
								<td>User since</th>
								<td><?php echo e($user['created_at']); ?></td>
							</tr>
						</table>
						<table>
							<tr>
								<td>
									<a href="javascript:history.back()" class="btn btn-primary" role="button">Return to list</a>
								</td>

								<input name="_method" type="hidden" value="DELETE">
									<button class="btn btn-danger" type="submit">Delete</button>
								</form>
							</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php else: ?>
<div class="row justify-content-center">
	<div class="alert alert-danger">
					You are not authorised to view this page
	</div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>