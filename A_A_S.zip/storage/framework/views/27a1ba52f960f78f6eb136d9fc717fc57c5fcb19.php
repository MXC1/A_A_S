<?php $__env->startSection('content'); ?>
<div class="listcontainer">
	<div class="row justify-content-center">
		<div class="col-md-8 ">
			<div class="card">
				<div class="card-header">Display all requests</div>
				<div class="card-body">
					<table class="table table-striped">
						<thead>
							<tr>
								<th>Request ID</th>
								<th>Request Made By</th>
								<th>Animal ID</th>
							</tr>
						</thead>
						
						<tbody>
<?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($request['id']); ?></td>
								<td><?php echo e($request['username']); ?></td>
								<td><?php echo e($request['animalid']); ?></td>
								<td>
									<a href="<?php echo e(action('AnimalController@show', $request['animalid'])); ?>" class="btn
btn- primary">Animal Details</a>
								</td>
								<td>
									<a href="<?php echo e(action('UserController@show', $request['username'])); ?>" class="btn
btn- warning">Requester Details</a>
								</td>
								<td>
									<form action="<?php echo e(action('RequestController@approve', $request['id'])); ?>"
method="POST"> <?php echo csrf_field(); ?>
											<input type="hidden" name="_method" value="PATCH">											
											<button class="btn btn-success" method="POST" type="submit"> Approve</button>
										</form>
									</td>
									<td>
									<form action="<?php echo e(action('RequestController@deny', $request['id'])); ?>"
method="POST"> <?php echo csrf_field(); ?>
											<input type="hidden" name="_method" value="PATCH">
											<button class="btn btn-danger" method="POST" type="submit"> Deny</button>
										</form>
									</td>
									
								</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>